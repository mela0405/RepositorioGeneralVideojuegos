using UnityEngine;

public class AnimationController : MonoBehaviour
{
    [SerializeField] private Animator _animator;
    [SerializeField] private MovementController _movement;

    private void Awake()
    {
        if (_animator == null)
            _animator = GetComponent<Animator>();

        if (_movement == null)
            _movement = GetComponent<MovementController>();
    }

    private void Update()
    {
        _animator.SetFloat(
            "Speed",
            _movement.CurrentSpeed,
            0.1f,
            Time.deltaTime
        );
    }
}
